Select codinf from [FIESTA-INFLABLE] --todos los inflables son 
									--usados en los locales de la empresa