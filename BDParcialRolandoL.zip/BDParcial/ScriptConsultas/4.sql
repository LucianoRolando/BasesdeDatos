


Select codcli, nombre from CLIENTES


exec FIESTREP